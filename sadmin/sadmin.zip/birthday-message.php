<?php
// birthday-message.php
session_start();
require_once '../includes/db-conn.php';

// Set Sri Lanka timezone
date_default_timezone_set("Asia/Colombo");

$today = date("m-d"); // ex: 09-08

$sql = "SELECT * FROM students WHERE DATE_FORMAT(birthday, '%m-%d') = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $today);
$stmt->execute();
$result = $stmt->get_result();
$messages = [];

while ($row = $result->fetch_assoc()) {
    $messages[] = [
        "title" => "Hey Admin!",
        "body"  => "Batch Year ".$row['batch_year']." ". $row['name']."  🎉 BirthDay Was Today!\nFrom Edulk",
        "icon"  => "https://cdn-icons-png.flaticon.com/512/190/190411.png"
    ];
}

echo json_encode($messages);
